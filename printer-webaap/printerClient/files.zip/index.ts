// index.ts — entry point
//
//   node-printer.exe             -> pastikan daemon jalan (tray), lalu buka TUI setup
//   node-printer.exe --setup     -> TUI setup saja
//   node-printer.exe --daemon    -> background + system tray
//   node-printer.exe install     -> auto-start saat login Windows
//   node-printer.exe uninstall   -> hapus auto-start
import { spawnSync } from "node:child_process";
import { isDaemonRunning, startDaemonDetached, runDaemon } from "./daemon";

const arg = process.argv[2];
const RUN_KEY = String.raw`HKCU\Software\Microsoft\Windows\CurrentVersion\Run`;

switch (arg) {
  case "--daemon":
    await runDaemon();
    break;

  case "--setup": {
    const { main } = await import("./setup");
    await main();
    break;
  }

  case "install": {
    const cmd = `"${process.execPath}" --daemon`;
    spawnSync("reg", ["add", RUN_KEY, "/v", "NodePrinter", "/t", "REG_SZ", "/d", cmd, "/f"], { stdio: "inherit" });
    console.log("✓ Auto-start aktif (jalan saat login).");
    break;
  }

  case "uninstall": {
    spawnSync("reg", ["delete", RUN_KEY, "/v", "NodePrinter", "/f"], { stdio: "inherit" });
    console.log("✓ Auto-start dihapus.");
    break;
  }

  default: {
    if (!(await isDaemonRunning())) {
      startDaemonDetached();
      await new Promise((r) => setTimeout(r, 800));
    }
    const { main } = await import("./setup");
    await main();
  }
}
