// setup.ts — Node Printer Setup (Bun + @clack/prompts)
import {
  intro, outro, note, log, text, select, multiselect,
  confirm, spinner, isCancel, cancel,
} from "@clack/prompts";
import pc from "picocolors";
import { mkdir, writeFile, readFile, chmod } from "node:fs/promises";
import { existsSync } from "node:fs";
import { homedir, platform } from "node:os";
import { join } from "node:path";
import { createCipheriv, randomBytes, scryptSync } from "node:crypto";

/* ───────────────────────── Config & Paths ───────────────────────── */

const CONF_DIR = join(homedir(), ".node-printer");
const SERVER_CONF = join(CONF_DIR, "server.conf");     // host (plain JSON)
const TOKEN_FILE = join(CONF_DIR, "token.enc");        // token (terenkripsi)
const PRINTER_CONF = join(CONF_DIR, "printers.conf");  // prioritas printer

// TODO: ganti sumber key enkripsi sesuai keputusanmu nanti
// (env var / machine-id / hardcode di build, dll)
const ENC_SECRET = process.env.NODE_PRINTER_SECRET ?? "CHANGE_ME_LATER";

const VERIFY_PATH = "/public/api/verifiedComputer.php";

interface ApiResponse {
  message: string;
  iseror: boolean;
  data: { status: string };
  responsesCode: number;
}

type Printer = { name: string; online: boolean; detail: string };
type PrinterConf = { name: string; priority: "high" | "normal" };

/* ───────────────────────── Helpers ───────────────────────── */

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** Tangani cancel (Ctrl+C / Esc) -> balik ke menu, bukan crash */
function cancelled<T>(v: T | symbol): v is symbol {
  if (isCancel(v)) {
    log.warn(pc.yellow("Dibatalkan, kembali ke menu..."));
    return true;
  }
  return false;
}

async function ensureDir() {
  await mkdir(CONF_DIR, { recursive: true });
}

function encrypt(plain: string): string {
  const salt = randomBytes(16);
  const key = scryptSync(ENC_SECRET, salt, 32);
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  const enc = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  // format: salt(16) | iv(12) | tag(16) | ciphertext
  return Buffer.concat([salt, iv, tag, enc]).toString("base64");
}

async function writeSecure(path: string, data: string) {
  await ensureDir();
  await writeFile(path, data, "utf8");
  if (platform() !== "win32") await chmod(path, 0o600);
}

async function readJson<T>(path: string): Promise<T | null> {
  if (!existsSync(path)) return null;
  try {
    return JSON.parse(await readFile(path, "utf8")) as T;
  } catch {
    return null;
  }
}

function normalizeHost(raw: string): string {
  let h = raw.trim().replace(/\/+$/, "");
  if (!/^https?:\/\//i.test(h)) h = "https://" + h;
  return h;
}

/* ───────────────────────── Banner & Status ───────────────────────── */

function banner() {
  console.clear();
  const art = [
    "  ╔╗╔╔═╗╔╦╗╔═╗  ╔═╗╦═╗╦╔╗╔╔╦╗╔═╗╦═╗",
    "  ║║║║ ║ ║║║╣   ╠═╝╠╦╝║║║║ ║ ║╣ ╠╦╝",
    "  ╝╚╝╚═╝═╩╝╚═╝  ╩  ╩╚═╩╝╚╝ ╩ ╚═╝╩╚═",
  ].join("\n");
  console.log(pc.cyan(art));
  console.log(pc.dim("  Setup node printer • v0.1.0\n"));
}

async function statusLine() {
  const server = await readJson<{ host: string }>(SERVER_CONF);
  const paired = server && existsSync(TOKEN_FILE);
  const printers = await readJson<PrinterConf[]>(PRINTER_CONF);
  const dot = (ok: boolean) => (ok ? pc.green("●") : pc.red("●"));

  note(
    `${dot(!!paired)} Server   : ${paired ? pc.green(server!.host) : pc.red("belum terhubung")}\n` +
      `${dot(!!printers?.length)} Printer  : ${
        printers?.length
          ? pc.green(`${printers.length} tersimpan`) +
            pc.dim(` (${printers.filter((p) => p.priority === "high").length} high)`)
          : pc.red("belum dikonfigurasi")
      }`,
    "Status"
  );
}

/* ───────────────────────── 1. Konek ke server ───────────────────────── */

async function verifyToken(host: string, token: string): Promise<ApiResponse> {
  const res = await fetch(host + VERIFY_PATH, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ token }),
    signal: AbortSignal.timeout(10_000),
  });

  const raw = await res.text();
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${raw.slice(0, 200)}`);

  let data: ApiResponse;
  try {
    data = JSON.parse(raw);
  } catch {
    throw new Error(`Response bukan JSON: ${raw.slice(0, 200)}`);
  }
  if (data.iseror) throw new Error(data.message || "Server mengembalikan error");
  return data;
}

async function connectServer() {
  note(
    "Alamat server harus halaman root saja.\n\n" +
      pc.red("✗ https://youtube.com/channel   → bukan root\n") +
      pc.green("✓ https://youtube.com           → benar"),
    "Aturan Penulisan Alamat Server"
  );

  while (true) {
    const host = await text({
      message: "Masukkan alamat server",
      placeholder: "https://serverKamu.com",
      validate: (v) => {
        if (!v?.trim()) return "Alamat tidak boleh kosong";
        try {
          const u = new URL(normalizeHost(v));
          if (u.pathname !== "/" && u.pathname !== "")
            return "Harus halaman root (tanpa path)";
        } catch {
          return "Format URL tidak valid";
        }
      },
    });
    if (cancelled(host)) return;

    const token = await text({
      message: "Masukkan token dari admin panel",
      placeholder: "Token: ************",
      validate: (v) => (v?.trim() ? undefined : "Token tidak boleh kosong"),
    });
    if (cancelled(token)) return;

    const hostUrl = normalizeHost(host as string);
    const s = spinner();
    s.start(`Memvalidasi ke ${pc.cyan(hostUrl)}`);

    try {
      const data = await verifyToken(hostUrl, (token as string).trim());
      s.stop(pc.green("✓ Token valid"));
      log.info(`Status  : ${pc.bold(data.data?.status ?? "-")}`);
      log.info(`Pesan   : ${data.message}`);

      const s2 = spinner();
      s2.start("Mengenkripsi & menyimpan konfigurasi");
      await writeSecure(SERVER_CONF, JSON.stringify({ host: hostUrl, pairedAt: new Date().toISOString() }, null, 2));
      await writeSecure(TOKEN_FILE, encrypt((token as string).trim()));
      await sleep(400);
      s2.stop(pc.green("✓ Tersimpan"));
      log.success(`Config : ${pc.dim(CONF_DIR)}`);
      await sleep(800);
      return;
    } catch (err) {
      s.stop(pc.red("✗ Gagal"));
      const msg = err instanceof Error ? err.message : String(err);
      // "grep" error → tampilkan ringkas
      log.error(pc.red(msg.split("\n")[0]!));

      const retry = await confirm({
        message: "Ulangi input?",
        initialValue: true,
      });
      if (cancelled(retry) || !retry) return;
    }
  }
}

/* ───────────────────────── 2. Printer ───────────────────────── */

async function listPrinters(): Promise<Printer[]> {
  const os = platform();

  if (os === "win32") {
    const out = await Bun.$`powershell -NoProfile -Command "Get-CimInstance Win32_Printer | Select-Object Name,WorkOffline,PrinterStatus | ConvertTo-Json -Compress"`
      .nothrow().quiet().text();
    if (!out.trim()) return [];
    const parsed = JSON.parse(out);
    const arr = Array.isArray(parsed) ? parsed : [parsed];
    return arr.map((p: any) => ({
      name: p.Name,
      online: !p.WorkOffline,
      detail: p.WorkOffline ? "offline" : "ready",
    }));
  }

  // Linux / macOS (CUPS)
  const out = await Bun.$`lpstat -p`.nothrow().quiet().text();
  const printers: Printer[] = [];
  for (const line of out.split("\n")) {
    const m = line.match(/^printer\s+(\S+)\s+(.*)$/);
    if (!m) continue;
    const rest = m[2]!;
    const disabled = /disabled/i.test(rest);
    printers.push({
      name: m[1]!,
      online: !disabled,
      detail: disabled ? "disabled" : /idle/i.test(rest) ? "idle" : "printing",
    });
  }
  return printers;
}

async function managePrinters() {
  const s = spinner();
  s.start("Mencari printer yang tersedia");
  let printers: Printer[] = [];
  try {
    printers = await listPrinters();
  } catch (err) {
    s.stop(pc.red("✗ Gagal membaca printer"));
    log.error(err instanceof Error ? err.message : String(err));
    await sleep(1200);
    return;
  }
  s.stop(`Ditemukan ${pc.bold(String(printers.length))} printer`);

  if (!printers.length) {
    log.warn("Tidak ada printer terdeteksi (cek CUPS / driver printer).");
    await sleep(1500);
    return;
  }

  // tabel status
  note(
    printers
      .map(
        (p) =>
          `${p.online ? pc.green("●") : pc.red("●")} ${pc.bold(p.name.padEnd(28))} ` +
          (p.online ? pc.green("HIDUP") : pc.red("MATI ")) +
          pc.dim(`  (${p.detail})`)
      )
      .join("\n"),
    "Status Printer"
  );

  const saved = (await readJson<PrinterConf[]>(PRINTER_CONF)) ?? [];
  const prevHigh = new Set(saved.filter((p) => p.priority === "high").map((p) => p.name));

  const picked = await multiselect({
    message: `Pilih printer ${pc.yellow("PRIORITAS HIGH")} ${pc.dim("(spasi = pilih, enter = lanjut)")}`,
    options: printers.map((p) => ({
      value: p.name,
      label: p.name,
      hint: p.online ? "hidup" : "mati",
    })),
    initialValues: printers.filter((p) => prevHigh.has(p.name)).map((p) => p.name),
    required: false,
  });
  if (cancelled(picked)) return;

  const high = new Set(picked as string[]);
  const offlineHigh = printers.filter((p) => high.has(p.name) && !p.online);
  if (offlineHigh.length) {
    log.warn(`Printer high yang sedang mati: ${offlineHigh.map((p) => p.name).join(", ")}`);
  }

  const conf: PrinterConf[] = printers.map((p) => ({
    name: p.name,
    priority: high.has(p.name) ? "high" : "normal",
  }));

  const ok = await confirm({ message: "Simpan konfigurasi printer?", initialValue: true });
  if (cancelled(ok) || !ok) return;

  await writeSecure(PRINTER_CONF, JSON.stringify(conf, null, 2));
  log.success(`Tersimpan di ${pc.dim(PRINTER_CONF)}`);
  await sleep(1000);
}

/* ───────────────────────── Main loop ───────────────────────── */

export async function main() {
  while (true) {
    banner();
    intro(pc.bgCyan(pc.black(" Node Printer Setup ")));
    await statusLine();

    const choice = await select({
      message: "Mau ngapain?",
      options: [
        { value: "server", label: "🔗  Konek ke server", hint: "pairing pakai token dari admin panel" },
        { value: "printer", label: "🖨️   Printer", hint: "lihat status & atur prioritas" },
        { value: "exit", label: "🚪  Keluar" },
      ],
    });

    if (isCancel(choice) || choice === "exit") {
      cancel("Setup ditutup. Node Printer tetap jalan di system tray.");
      process.exit(0);
    }

    if (choice === "server") await connectServer();
    if (choice === "printer") await managePrinters();
  }
}
