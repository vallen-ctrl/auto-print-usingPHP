// daemon.ts — background process + system tray (Windows)
import net from "node:net";
import { spawn, type ChildProcess } from "node:child_process";
import { mkdir, writeFile, readFile, appendFile } from "node:fs/promises";
import { watch, existsSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
import { createDecipheriv, scryptSync } from "node:crypto";

export const CONF_DIR = join(homedir(), ".node-printer");
const SERVER_CONF = join(CONF_DIR, "server.conf");
const TOKEN_FILE = join(CONF_DIR, "token.enc");
const PRINTER_CONF = join(CONF_DIR, "printers.conf");
const TRAY_SCRIPT = join(CONF_DIR, "tray.ps1");
const LOG_FILE = join(CONF_DIR, "daemon.log");

// Samakan dengan ENC_SECRET di setup.ts
const ENC_SECRET = process.env.NODE_PRINTER_SECRET ?? "CHANGE_ME_LATER";

// Port lokal dipakai sebagai "lock" single-instance
const LOCK_PORT = 47831;

/* ───────────── Self command (dev vs compiled) ───────────── */

const COMPILED = Bun.main.includes("~BUN") || Bun.main.includes("$bunfs");

function selfCmd(args: string[]): string[] {
  return COMPILED
    ? [process.execPath, ...args]
    : [process.execPath, Bun.main, ...args];
}

const q = (s: string) => `"${s}"`;

/* ───────────── Daemon control (dipanggil dari launcher) ───────────── */

export function isDaemonRunning(): Promise<boolean> {
  return new Promise((resolve) => {
    const sock = net.connect({ host: "127.0.0.1", port: LOCK_PORT });
    sock.setTimeout(800);
    sock.once("connect", () => { sock.destroy(); resolve(true); });
    sock.once("timeout", () => { sock.destroy(); resolve(false); });
    sock.once("error", () => resolve(false));
  });
}

export function startDaemonDetached() {
  const [cmd, ...args] = selfCmd(["--daemon"]);
  spawn(cmd!, args, {
    detached: true,
    windowsHide: true,
    stdio: "ignore",
  }).unref();
}

/** Buka jendela console baru berisi TUI setup */
export function openSetupWindow() {
  const full = selfCmd(["--setup"]).map(q).join(" ");
  spawn("cmd.exe", ["/c", `start "Node Printer Setup" ${full}`], {
    detached: true,
    windowsHide: false,
    windowsVerbatimArguments: true,
    stdio: "ignore",
  }).unref();
}

/* ───────────── Logging ───────────── */

async function log(msg: string) {
  const line = `[${new Date().toISOString()}] ${msg}\n`;
  try { await appendFile(LOG_FILE, line); } catch {}
}

/* ───────────── Config & token ───────────── */

function decrypt(b64: string): string {
  const buf = Buffer.from(b64, "base64");
  const salt = buf.subarray(0, 16);
  const iv = buf.subarray(16, 28);
  const tag = buf.subarray(28, 44);
  const data = buf.subarray(44);
  const key = scryptSync(ENC_SECRET, salt, 32);
  const d = createDecipheriv("aes-256-gcm", key, iv);
  d.setAuthTag(tag);
  return Buffer.concat([d.update(data), d.final()]).toString("utf8");
}

async function loadConfig() {
  if (!existsSync(SERVER_CONF) || !existsSync(TOKEN_FILE)) return null;
  const server = JSON.parse(await readFile(SERVER_CONF, "utf8")) as { host: string };
  const token = decrypt(await readFile(TOKEN_FILE, "utf8"));
  const printers = existsSync(PRINTER_CONF)
    ? (JSON.parse(await readFile(PRINTER_CONF, "utf8")) as { name: string; priority: string }[])
    : [];
  return { host: server.host, token, printers };
}

/* ───────────── Worker (isi logika node printer di sini) ───────────── */

async function startWorker() {
  try {
    const cfg = await loadConfig();
    if (!cfg) return void (await log("Belum dipairing, worker idle."));
    await log(`Worker aktif -> ${cfg.host} | printer: ${cfg.printers.length}`);

    // TODO: polling / websocket ke server, ambil job, kirim ke printer
    // prioritas: cfg.printers.filter(p => p.priority === "high") dipakai dulu
  } catch (e) {
    await log("Worker error: " + (e instanceof Error ? e.message : String(e)));
  }
}

/* ───────────── Tray (PowerShell NotifyIcon, tanpa dependency) ───────────── */

const TRAY_PS1 = String.raw`
param([int]$ParentPid)
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$script:icon = New-Object System.Windows.Forms.NotifyIcon
$script:icon.Icon = [System.Drawing.SystemIcons]::Application
$script:icon.Text = "Node Printer (berjalan)"
$script:icon.Visible = $true

$menu = New-Object System.Windows.Forms.ContextMenuStrip
$title = $menu.Items.Add("Node Printer")
$title.Enabled = $false
[void]$menu.Items.Add("-")
$open = $menu.Items.Add("Buka Setup")
$exit = $menu.Items.Add("Keluar")

$open.add_Click({ [Console]::Out.WriteLine("open") })
$exit.add_Click({
  [Console]::Out.WriteLine("exit")
  $script:icon.Visible = $false
  [System.Windows.Forms.Application]::Exit()
})
$script:icon.add_DoubleClick({ [Console]::Out.WriteLine("open") })
$script:icon.ContextMenuStrip = $menu

# kalau proses induk mati, tray ikut mati
$script:pp = $ParentPid
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 3000
$timer.add_Tick({
  if (-not (Get-Process -Id $script:pp -ErrorAction SilentlyContinue)) {
    $script:icon.Visible = $false
    [System.Windows.Forms.Application]::Exit()
  }
})
$timer.Start()

[System.Windows.Forms.Application]::Run()
`;

async function startTray(onOpen: () => void, onExit: () => void): Promise<ChildProcess> {
  await writeFile(TRAY_SCRIPT, TRAY_PS1, "utf8");
  const ps = spawn(
    "powershell.exe",
    [
      "-NoProfile", "-ExecutionPolicy", "Bypass", "-STA",
      "-WindowStyle", "Hidden",
      "-File", TRAY_SCRIPT,
      "-ParentPid", String(process.pid),
    ],
    { windowsHide: true, stdio: ["ignore", "pipe", "ignore"] }
  );

  let buf = "";
  ps.stdout!.on("data", (d: Buffer) => {
    buf += d.toString();
    let i;
    while ((i = buf.indexOf("\n")) >= 0) {
      const cmd = buf.slice(0, i).trim();
      buf = buf.slice(i + 1);
      if (cmd === "open") onOpen();
      if (cmd === "exit") onExit();
    }
  });
  ps.on("exit", () => onExit());
  return ps;
}

/* ───────────── Entry daemon ───────────── */

export async function runDaemon() {
  await mkdir(CONF_DIR, { recursive: true });

  // single instance
  const server = net.createServer((s) => s.end());
  await new Promise<void>((resolve) => {
    server.once("error", () => process.exit(0)); // sudah ada daemon lain
    server.listen(LOCK_PORT, "127.0.0.1", () => resolve());
  });

  await log("Daemon start");
  await startWorker();

  // auto-reload kalau config diubah dari TUI
  let t: ReturnType<typeof setTimeout> | undefined;
  watch(CONF_DIR, (_e, file) => {
    if (!file || file === "daemon.log" || file === "tray.ps1") return;
    clearTimeout(t);
    t = setTimeout(async () => {
      await log(`Config berubah (${file}), reload`);
      await startWorker();
    }, 500);
  });

  const tray = await startTray(
    () => openSetupWindow(),
    async () => {
      await log("Daemon exit");
      server.close();
      process.exit(0);
    }
  );
  process.on("exit", () => tray.kill());

  // jaga proses tetap hidup
  setInterval(() => {}, 1 << 30);
}
